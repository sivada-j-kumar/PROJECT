import os
from pathlib import Path

from flask import Flask
from sqlalchemy import inspect, text
from werkzeug.security import generate_password_hash

from .config import Config
from .extensions.extensions import db, init_extensions, login_manager
from .repositories.user_repository import UserRepository
from .routes.auth_routes import auth_bp
from .models.user_model import ROLE_ADMIN, ROLE_WORKER


@login_manager.user_loader
def load_user(user_id):
    return UserRepository.get_user_by_id(user_id)


def _ensure_schema_columns():
    inspector = inspect(db.engine)
    if "user" not in inspector.get_table_names():
        return

    existing_columns = [column["name"] for column in inspector.get_columns("user")]
    if "role" not in existing_columns:
        db.session.execute(
            text("ALTER TABLE user ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'worker'")
        )
        db.session.commit()

    if "department" not in existing_columns:
        db.session.execute(
            text("ALTER TABLE user ADD COLUMN department VARCHAR(150)")
        )
        db.session.commit()

    if "status" not in existing_columns:
        db.session.execute(
            text("ALTER TABLE user ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'active'" )
        )
        db.session.commit()


def _ensure_default_admin():
    existing_admin = UserRepository.get_user_by_role(ROLE_ADMIN)
    if existing_admin:
        return

    admin_email = os.environ.get("DEFAULT_ADMIN_EMAIL", "admin@bionova.com")
    admin_password = os.environ.get("DEFAULT_ADMIN_PASSWORD", "Admin1234!")
    hashed_password = generate_password_hash(admin_password)
    UserRepository.create_user(
        username="admin",
        email=admin_email,
        password_hash=hashed_password,
        role=ROLE_ADMIN,
        department="Administration",
    )


def create_app():
    app = Flask(__name__, template_folder="../templates", static_folder="../static")
    app.config.from_object(Config)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)

    init_extensions(app)

    app.register_blueprint(auth_bp)

    with app.app_context():
        db.create_all()
        _ensure_schema_columns()
        _ensure_default_admin()

    return app
