from werkzeug.security import generate_password_hash, check_password_hash
from ..repositories.user_repository import UserRepository
from ..models.user_model import ROLE_CHOICES, ROLE_WORKER, STATUS_ACTIVE, STATUS_PENDING


class AuthService:
    @staticmethod
    def signup(username, email, password, role=ROLE_WORKER, department=None):
        normalized_username = (username or "").strip()
        normalized_email = (email or "").strip().lower()
        raw_password = password or ""
        normalized_role = (role or ROLE_WORKER).strip().lower()

        if normalized_role not in ROLE_CHOICES:
            return None, "Invalid role selected."

        if not normalized_username or not normalized_email or not raw_password:
            return None, "All fields are required."

        if len(normalized_username) < 3:
            return None, "Username must be at least 3 characters long."

        if "@" not in normalized_email or "." not in normalized_email.split("@")[-1]:
            return None, "Please enter a valid email address."

        if len(raw_password) < 8:
            return None, "Password must be at least 8 characters long."

        if UserRepository.get_user_by_email(normalized_email):
            return None, "Email already registered."

        if UserRepository.get_user_by_username(normalized_username):
            return None, "Username already taken."

        hashed_password = generate_password_hash(raw_password)
        user_status = STATUS_PENDING if normalized_role == ROLE_WORKER else STATUS_ACTIVE
        user = UserRepository.create_user(
            username=normalized_username,
            email=normalized_email,
            password_hash=hashed_password,
            role=normalized_role,
            department=(department or None),
            status=user_status,
        )
        return user, None

    @staticmethod
    def login(email, password):
        normalized_email = (email or "").strip().lower()
        raw_password = password or ""

        if not normalized_email or not raw_password:
            return None, "Email and password are required."

        user = UserRepository.get_user_by_email(normalized_email)
        if user and check_password_hash(user.password_hash, raw_password):
            return user, None

        return None, "Invalid email or password."

    @staticmethod
    def change_password(user, current_password, new_password, confirm_password):
        current_password = current_password or ""
        new_password = new_password or ""
        confirm_password = confirm_password or ""

        if not current_password or not new_password or not confirm_password:
            return None, "All password fields are required."

        if not check_password_hash(user.password_hash, current_password):
            return None, "Current password is incorrect."

        if len(new_password) < 8:
            return None, "New password must be at least 8 characters long."

        if new_password != confirm_password:
            return None, "New password and confirmation do not match."

        hashed_password = generate_password_hash(new_password)
        UserRepository.update_password(user, hashed_password)
        return user, None
