from ..extensions.extensions import db
from flask_login import UserMixin

ROLE_ADMIN = "admin"
ROLE_MANAGER = "manager"
ROLE_WORKER = "worker"
ROLE_QUALITY = "quality"

ROLE_CHOICES = [ROLE_ADMIN, ROLE_MANAGER, ROLE_WORKER, ROLE_QUALITY]
STATUS_ACTIVE = "active"
STATUS_PENDING = "pending"
STATUS_DENIED = "denied"
STATUS_CHOICES = [STATUS_ACTIVE, STATUS_PENDING, STATUS_DENIED]


class User(db.Model, UserMixin):
    __tablename__ = "user"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column("password", db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default=ROLE_WORKER)
    department = db.Column(db.String(150), nullable=True)
    status = db.Column(db.String(20), nullable=False, default=STATUS_ACTIVE)

    @property
    def is_admin(self):
        return self.role == ROLE_ADMIN

    @property
    def is_manager(self):
        return self.role == ROLE_MANAGER

    @property
    def is_worker(self):
        return self.role == ROLE_WORKER

    @property
    def is_quality(self):
        return self.role == ROLE_QUALITY

    @property
    def is_pending(self):
        return self.status == STATUS_PENDING

    @property
    def is_active(self):
        return self.status == STATUS_ACTIVE

    @property
    def is_denied(self):
        return self.status == STATUS_DENIED

    def __repr__(self):
        return f"<User {self.username} ({self.role}, {self.status})>"
