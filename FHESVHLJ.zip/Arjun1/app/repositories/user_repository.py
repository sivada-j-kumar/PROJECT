from ..models.user_model import User, ROLE_WORKER
from ..extensions.extensions import db


class UserRepository:
    @staticmethod
    def get_user_by_id(user_id):
        try:
            return db.session.get(User, int(user_id))
        except (TypeError, ValueError):
            return None

    @staticmethod
    def get_user_by_email(email):
        return User.query.filter_by(email=email).first()

    @staticmethod
    def get_user_by_username(username):
        return User.query.filter_by(username=username).first()

    @staticmethod
    def get_user_by_role(role):
        return User.query.filter_by(role=role).first()

    @staticmethod
    def create_user(username, email, password_hash, role="worker", department=None, status="active"):
        user = User(
            username=username,
            email=email,
            password_hash=password_hash,
            role=role,
            department=department or None,
            status=status,
        )
        db.session.add(user)
        db.session.commit()
        return user

    @staticmethod
    def update_password(user, password_hash):
        user.password_hash = password_hash
        db.session.commit()
        return user

    @staticmethod
    def update_status(user, status):
        user.status = status
        db.session.commit()
        return user

    @staticmethod
    def get_pending_workers():
        return User.query.filter_by(role=ROLE_WORKER, status="pending").order_by(User.username).all()

    @staticmethod
    def get_all_users():
        return User.query.order_by(User.role.desc(), User.username).all()
