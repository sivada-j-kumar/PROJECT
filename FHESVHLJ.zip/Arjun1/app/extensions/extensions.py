from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login_page"
login_manager.login_message = "Please log in to continue."
login_manager.login_message_category = "info"


def init_extensions(app):
    db.init_app(app)
    login_manager.init_app(app)
