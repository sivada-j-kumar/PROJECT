from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, abort
from flask_login import login_user, logout_user, login_required, current_user
from ..services.auth_service import AuthService
from ..models.user_model import ROLE_ADMIN, ROLE_MANAGER, ROLE_WORKER, ROLE_QUALITY, STATUS_ACTIVE, STATUS_PENDING, STATUS_DENIED
from ..repositories.user_repository import UserRepository

auth_bp = Blueprint("auth", __name__)

@auth_bp.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for("auth.dashboard"))
    return render_template("login.html")

@auth_bp.route('/login')
def login():
    if current_user.is_authenticated:
        return redirect(url_for("auth.dashboard"))
    return render_template("login_role_select.html")

@auth_bp.route('/register')
def register():
    if current_user.is_authenticated:
        return redirect(url_for("auth.dashboard"))
    return render_template("register_role_select.html")

@auth_bp.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for("auth.dashboard"))

    role = request.args.get('role', 'worker')  # default to worker
    form_data = {"username": "", "email": "", "department": "", "role": role}

    if request.method == 'POST':
        username = request.form.get("username", "")
        email = request.form.get("email", "")
        password = request.form.get("password", "")
        department = request.form.get("department", "")
        form_data = {"username": username, "email": email, "department": department, "role": role}

        # Map role string to constant
        role_constant = {
            'admin': ROLE_ADMIN,
            'manager': ROLE_MANAGER,
            'worker': ROLE_WORKER
        }.get(role, ROLE_WORKER)

        user, error = AuthService.signup(username, email, password, role=role_constant, department=department)
        if error:
            flash(error, "error")
            return render_template("signup.html", form_data=form_data), 400

        if role_constant == ROLE_WORKER:
            flash("Worker account created successfully and is pending admin approval.", "success")
        else:
            flash(f"{role.capitalize()} account created successfully. Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("signup.html", form_data=form_data)

@auth_bp.route('/login/form', methods=['GET', 'POST'])
def login_page():
    if current_user.is_authenticated:
        return redirect(url_for("auth.dashboard"))

    role = request.args.get('role', 'worker')  # default to worker if not specified
    form_data = {"email": "", "role": role}

    if request.method == 'POST':
        email = request.form.get("email", "")
        password = request.form.get("password", "")
        form_data = {"email": email, "role": role}

        user, error = AuthService.login(email, password)
        if error:
            flash(error, "error")
            return render_template("login_form.html", form_data=form_data), 400

        # Check if user's role matches the requested login role
        if role == 'admin' and not user.is_admin:
            flash("Access denied. This login is for administrators only.", "error")
            return render_template("login_form.html", form_data=form_data), 403
        elif role == 'manager' and not user.is_manager:
            flash("Access denied. This login is for managers only.", "error")
            return render_template("login_form.html", form_data=form_data), 403
        elif role == 'worker' and not user.is_worker:
            flash("Access denied. This login is for workers only.", "error")
            return render_template("login_form.html", form_data=form_data), 403

        if user.role == ROLE_WORKER and user.status != STATUS_ACTIVE:
            if user.status == STATUS_PENDING:
                flash("Your worker account is pending approval. An admin will approve you shortly.", "info")
            elif user.status == STATUS_DENIED:
                flash("Your worker account has been denied. Contact an administrator.", "error")
            return render_template("login_form.html", form_data=form_data), 403

        login_user(user)
        flash(f"Login successful. Welcome back, {user.username}!", "success")
        return redirect(url_for("auth.dashboard"))

    return render_template("login_form.html", form_data=form_data)

@auth_bp.route('/manager/create-worker', methods=['GET', 'POST'])
@login_required
def create_worker():
    if not current_user.is_manager:
        abort(403)

    form_data = {"username": "", "email": "", "department": ""}

    if request.method == 'POST':
        username = request.form.get("username", "")
        email = request.form.get("email", "")
        password = request.form.get("password", "")
        department = request.form.get("department", "")
        form_data = {"username": username, "email": email, "department": department}

        user, error = AuthService.signup(username, email, password, role=ROLE_WORKER, department=department)
        if error:
            flash(error, "error")
            return render_template("manager_create_worker.html", form_data=form_data), 400

        flash("Worker account created successfully.", "success")
        return redirect(url_for("auth.dashboard"))

    return render_template("manager_create_worker.html", form_data=form_data)

@auth_bp.route('/admin/approve-worker/<int:user_id>', methods=['POST'])
@login_required
def approve_worker(user_id):
    if not current_user.is_admin:
        abort(403)

    user = UserRepository.get_user_by_id(user_id)
    if not user or user.role != ROLE_WORKER:
        abort(404)

    UserRepository.update_status(user, STATUS_ACTIVE)
    flash(f"Worker {user.username} has been approved.", "success")
    return redirect(url_for("auth.dashboard"))

@auth_bp.route('/admin/reject-worker/<int:user_id>', methods=['POST'])
@login_required
def reject_worker(user_id):
    if not current_user.is_admin:
        abort(403)

    user = UserRepository.get_user_by_id(user_id)
    if not user or user.role != ROLE_WORKER:
        abort(404)

    UserRepository.update_status(user, STATUS_DENIED)
    flash(f"Worker {user.username} has been denied access.", "error")
    return redirect(url_for("auth.dashboard"))

@auth_bp.route('/admin/create-account', methods=['GET', 'POST'])
@login_required
def create_account():
    if not current_user.is_admin:
        abort(403)

    form_data = {"username": "", "email": "", "department": "", "role": "manager"}

    if request.method == 'POST':
        username = request.form.get("username", "")
        email = request.form.get("email", "")
        password = request.form.get("password", "")
        department = request.form.get("department", "")
        role = request.form.get("role", "manager")
        form_data = {"username": username, "email": email, "department": department, "role": role}

        # Validate role
        valid_roles = [ROLE_MANAGER, ROLE_WORKER, ROLE_QUALITY]
        if role not in valid_roles:
            flash("Invalid role selected.", "error")
            return render_template("admin_create_account.html", form_data=form_data), 400

        user, error = AuthService.signup(username, email, password, role=role, department=department)
        if error:
            flash(error, "error")
            return render_template("admin_create_account.html", form_data=form_data), 400

        flash(f"{role.capitalize()} account created successfully.", "success")
        return redirect(url_for("auth.dashboard"))

    return render_template("admin_create_account.html", form_data=form_data)

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash("You have been logged out securely.", "info")
    return redirect(url_for("auth.index"))

@auth_bp.route('/change-password', methods=['POST'])
@login_required
def change_password():
    current_password = request.form.get('current_password', '')
    new_password = request.form.get('new_password', '')
    confirm_password = request.form.get('confirm_password', '')

    user, error = AuthService.change_password(
        current_user,
        current_password,
        new_password,
        confirm_password,
    )

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': error is None,
            'message': 'Password updated successfully.' if error is None else error,
        })

    if error:
        flash(error, 'error')
    else:
        flash('Password updated successfully.', 'success')

    return redirect(url_for('auth.dashboard'))

@auth_bp.route('/dashboard')
@login_required
def dashboard():
    from ..repositories.user_repository import UserRepository
    users = UserRepository.get_all_users()

    if current_user.is_admin:
        template = 'dashboard.html'
    elif current_user.is_manager:
        template = 'manager_dashboard.html'
    elif current_user.is_quality:
        template = 'quality_dashboard.html'
    else:
        template = 'dashboard.html'

    return render_template(template, users=users)
