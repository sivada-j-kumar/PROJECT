#!/usr/bin/env python3
"""Test database connection and initialization"""

from app import create_app
from app.repositories.user_repository import UserRepository

app = create_app()
print("[+] Flask app created successfully")

with app.app_context():
    print("[+] Database connection verified")
    
    # Check for admin
    admin = UserRepository.get_user_by_role('admin')
    if admin:
        print(f"[+] Admin account: {admin.username} ({admin.email})")
    
    # Count all users
    all_users = UserRepository.get_all_users()
    print(f"[+] Total users in database: {len(all_users)}")
    
    print("\n[SUCCESS] Database is fully initialized and ready to use!")
    print(f"[INFO] Database path: {app.config['SQLALCHEMY_DATABASE_URI']}")
