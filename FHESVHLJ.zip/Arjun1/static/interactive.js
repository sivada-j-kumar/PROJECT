// ==========================================
// BIONOVA INTERACTIVE EFFECTS & ANIMATIONS
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    initializeInteractiveElements();
    initializeTooltips();
    initializeToggleButtons();
    initializeNavigation();
    initializeHoverEffects();
    addPageTransitions();
});

// ==========================================
// 1. POPUP TOOLTIPS ON HOVER
// ==========================================

function initializeTooltips() {
    const elements = document.querySelectorAll('[data-tooltip]');
    
    elements.forEach(element => {
        const tooltip = element.getAttribute('data-tooltip');
        const position = element.getAttribute('data-tooltip-position') || 'top';
        
        // Create tooltip element
        const tooltipEl = document.createElement('div');
        tooltipEl.className = 'popup-tooltip';
        tooltipEl.textContent = tooltip;
        tooltipEl.style.position = 'absolute';
        
        // Position tooltip based on data attribute
        switch(position) {
            case 'bottom':
                tooltipEl.style.bottom = 'auto';
                tooltipEl.style.top = 'calc(100% + 12px)';
                break;
            case 'left':
                tooltipEl.style.right = 'calc(100% + 12px)';
                tooltipEl.style.left = 'auto';
                break;
            case 'right':
                tooltipEl.style.left = 'calc(100% + 12px)';
                break;
            default: // top
                tooltipEl.style.bottom = 'calc(100% + 12px)';
                tooltipEl.style.top = 'auto';
        }
        
        element.style.position = 'relative';
        element.appendChild(tooltipEl);
        
        // Hover events
        element.addEventListener('mouseenter', function() {
            element.classList.add('tooltip-active');
        });
        
        element.addEventListener('mouseleave', function() {
            element.classList.remove('tooltip-active');
        });
    });
}

// ==========================================
// 2. TOGGLE BUTTONS
// ==========================================

function initializeToggleButtons() {
    const toggleBtns = document.querySelectorAll('.toggle-btn');
    
    toggleBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Toggle active state
            this.classList.toggle('active');
            
            // Trigger animation
            const icon = this.querySelector('.toggle-btn-icon');
            if (icon) {
                icon.style.transform = this.classList.contains('active') 
                    ? 'rotate(180deg) scale(1.2)' 
                    : 'rotate(0deg) scale(1)';
            }
            
            // Fire custom event
            const event = new CustomEvent('toggle-changed', {
                detail: { 
                    element: this,
                    isActive: this.classList.contains('active')
                }
            });
            this.dispatchEvent(event);
        });
    });
}

// ==========================================
// 3. NAVBAR HIGHLIGHT ON SCROLL
// ==========================================

function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link, .nav-item');
    
    // Add smooth scroll behavior
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href && href.startsWith('#')) {
                e.preventDefault();
                
                // Remove active class from all links
                navLinks.forEach(l => l.classList.remove('active'));
                
                // Add active class to current link
                this.classList.add('active');
                
                // Scroll to target
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });
}

// ==========================================
// 4. INTERACTIVE HOVER EFFECTS
// ==========================================

function initializeHoverEffects() {
    // Card lift effect
    const cards = document.querySelectorAll('.card, .panel, .summary-card, .device-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
            this.style.boxShadow = '0 20px 40px rgba(13, 105, 121, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '';
        });
    });
    
    // Button ripple effect
    const buttons = document.querySelectorAll('.btn, button');
    
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.className = 'ripple';
            
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });
}

// ==========================================
// 5. PAGE TRANSITION EFFECTS
// ==========================================

function addPageTransitions() {
    // Add animation to page load
    const mainContent = document.querySelector('main');
    if (mainContent) {
        mainContent.classList.add('page-transition');
    }
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#' && document.querySelector(href)) {
                e.preventDefault();
                document.querySelector(href).scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ==========================================
// 6. FLOATING ACTION BUTTON
// ==========================================

function addFloatingActionButton(icon = '✨', onClick = null) {
    const fab = document.createElement('button');
    fab.className = 'fab';
    fab.innerHTML = icon;
    fab.setAttribute('data-tooltip', 'Quick Action');
    
    if (onClick) {
        fab.addEventListener('click', onClick);
    }
    
    document.body.appendChild(fab);
}

// ==========================================
// 7. NOTIFICATION TOAST
// ==========================================

function showToast(message, type = 'info', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} flash flash-${type}`;
    toast.setAttribute('role', 'alert');
    toast.textContent = message;
    
    const container = document.querySelector('.flash-stack') || document.body;
    container.insertBefore(toast, container.firstChild);
    
    // Auto remove
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.4s ease';
        setTimeout(() => toast.remove(), 400);
    }, duration);
}

// ==========================================
// 8. SMOOTH SCROLLING
// ==========================================

document.addEventListener('scroll', function() {
    const scrollPosition = window.scrollY;
    
    // Parallax effect for hero section
    const hero = document.querySelector('.hero-card');
    if (hero) {
        hero.style.transform = `translateY(${scrollPosition * 0.5}px)`;
    }
});

// ==========================================
// 9. FORM VALIDATION WITH VISUAL FEEDBACK
// ==========================================

function setupFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            const inputs = this.querySelectorAll('input, textarea, select');
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    input.style.borderColor = 'var(--error)';
                    input.style.boxShadow = '0 0 0 3px rgba(179, 77, 77, 0.1)';
                    isValid = false;
                } else {
                    input.style.borderColor = 'var(--success)';
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                showToast('Please fill all required fields', 'error');
            }
        });
    });
}

// ==========================================
// 10. SEARCH INPUT WITH SUGGESTIONS
// ==========================================

function initializeSearch() {
    const searchInputs = document.querySelectorAll('input[type="search"]');
    
    searchInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.style.background = 'rgba(13, 105, 121, 0.02)';
        });
        
        input.addEventListener('blur', function() {
            this.style.background = '';
        });
        
        input.addEventListener('input', function(e) {
            const value = e.target.value;
            
            // Add visual feedback
            if (value.length > 0) {
                this.style.borderColor = 'var(--primary)';
                this.style.boxShadow = '0 0 0 3px rgba(13, 105, 121, 0.1)';
            } else {
                this.style.borderColor = '';
                this.style.boxShadow = '';
            }
        });
    });
}

// ==========================================
// 11. DARK MODE TOGGLE (Optional)
// ==========================================

function setupDarkModeToggle() {
    const darkModeBtn = document.querySelector('[data-toggle="dark-mode"]');
    
    if (darkModeBtn) {
        const isDarkMode = localStorage.getItem('darkMode') === 'true';
        
        if (isDarkMode) {
            document.documentElement.style.filter = 'invert(1)';
            darkModeBtn.classList.add('active');
        }
        
        darkModeBtn.addEventListener('click', function() {
            const isDark = document.documentElement.style.filter === 'invert(1)';
            
            if (isDark) {
                document.documentElement.style.filter = '';
                localStorage.setItem('darkMode', 'false');
                this.classList.remove('active');
            } else {
                document.documentElement.style.filter = 'invert(1)';
                localStorage.setItem('darkMode', 'true');
                this.classList.add('active');
            }
        });
    }
}

// ==========================================
// 12. UTILITY FUNCTIONS
// ==========================================

// Animate numbers counting up
function animateCounter(element, target, duration = 1000) {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Add ripple CSS if not already present
function addRippleStyles() {
    if (!document.querySelector('style[data-ripple]')) {
        const style = document.createElement('style');
        style.setAttribute('data-ripple', 'true');
        style.textContent = `
            .ripple {
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                transform: scale(0);
                animation: ripple-animation 0.6s ease-out;
                pointer-events: none;
            }
            
            @keyframes ripple-animation {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
            
            @keyframes fadeOut {
                to {
                    opacity: 0;
                    transform: translateY(-20px);
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// Initialize all interactive features
function initializeInteractiveElements() {
    addRippleStyles();
    setupFormValidation();
    initializeSearch();
    setupDarkModeToggle();
}

// Export functions for use in templates
window.BioNova = {
    showToast,
    addFloatingActionButton,
    animateCounter,
    setupFormValidation
};
